<?php session_start();
//error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['aid']==0)) {
  header('location:logout.php');
  } else{

if(isset($_POST['submit'])){
	
$cdata=$_POST['Category-short'];
$categorydata=explode('-',$cdata);
$cshortname=$categorydata['0'];
$cfullname=$categorydata['1'];
$sb1=$_POST['pet1'];
$sb2=$_POST['pet2'];
$sb3=$_POST['pet3'];
$sb4=$_POST['pet4'];
$query=mysqli_query($con,"insert into pet(cname,cfull,pet1,pet2,pet3,pet4)values('$cshortname','$cfullname','$sb1','$sb2','$sb3','$sb4')");
if($query){
echo '<script>alert("Pet Added successfully")</script>';
echo "<script>window.location.href='manage-pet.php'</script>";
} else{
echo '<script>alert("Something went wrong. Please try again")</script>';
echo '<script>window.location.href=add-pet.php</script>';
}
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title></title>
<link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
<link href="dist/css/sb-admin-2.css" rel="stylesheet">
<link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>

<body>
<form method="post" >
	<div id="wrapper">

		<!-- Navigation -->
		<?php include('leftbar.php')?>;


		<div id="page-wrapper">
			<div class="row">
				<div class="col-lg-12">
					<h4 class="page-header"> <?php echo strtoupper("welcome"." ".htmlentities($_SESSION['login']));?></h4>
				</div>
				<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-heading">Add Pet</div>
						<div class="panel-body">
							<div class="row">
						 	<div class="col-lg-10">
									
										<div class="form-group">
											<div class="col-lg-4">
					 <label>Category Name<span id="" style="font-size:11px;color:Red">*</span>	</label>
											</div>
			
			<div class="col-lg-6">
			<select class="form-control" name="Category-short" id="cname" onchange="categoryAvailability()" required="required" >
			<option VALUE="">SELECT</option>
				<?php $query=mysqli_query($con,"select * from tbl_category");
				while($res=mysqli_fetch_array($query)){
					?>							
			
                        <option VALUE="<?php echo htmlentities($res['cid']."-".$res['cfull']);?>"><?php echo htmlentities($res['cname'])?> (<?php echo htmlentities($res['cfull'])?>)</option>
                        
                        
                    <?php }?>   			</div>
											 
                        </select>
					<span id="course-availability-status" style="font-size:12px;"></span>	
					</div>
					    </div>	
										
								<br><br>
								
								
		<div class="form-group">
		<div class="col-lg-4">
		<label>Pet 1</label>
		</div>
		<div class="col-lg-6">
		<input class="form-control" type="file"  name="pet1" required>
	</div>
	 </div>	
	<br><br>	

     <div class="form-group">
		<div class="col-lg-4">
		<label>Pet 2</label>
		</div>
		<div class="col-lg-6">
		<input class="form-control" type="file" name="pet2" required>
	 </div>
	 </div>	
	<br><br>									
	<div class="form-group">
	<div class="col-lg-4">
	 <label>Pet 3</label>
	</div>
	<div class="col-lg-6">
	<input class="form-control" type="file" name="pet3" required>
	
	</div>
	</div>


	<br><br>									
	<div class="form-group">
	<div class="col-lg-4">
	 <label>Pet 4</label>
	</div>
	<div class="col-lg-6">
	<input class="form-control" type="file" name="pet4" >
	</div>
	</div>


	</div>	
	<br><br><br>								
										
	<div class="form-group">
											<div class="col-lg-4">
												
											</div>
											<div class="col-lg-6"><br><br>
	<input type="submit" class="btn btn-primary" name="submit" value="Add Pet"></button>
											</div>
											
										</div>		
													
				</div>

					</div>
								
							</div>
							
						</div>
						
					</div>
					
				</div>
				
			</div>
			
		</div>
		

	</div>
	

	<!-- jQuery -->
	<script src="bower_components/jquery/dist/jquery.min.js" type="text/javascript"></script>
	<!-- Bootstrap Core JavaScript -->
	<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
	<!-- Metis Menu Plugin JavaScript -->
	<script src="../bower_components/metisMenu/dist/metisMenu.min.js"
		type="text/javascript"></script>
	<!-- Custom Theme JavaScript -->
	<script src="../dist/js/sb-admin-2.js" type="text/javascript"></script>
	<script>
function categoryAvailability() {
	$("#loaderIcon").show();
jQuery.ajax({
url: "category_availability.php",
data:'cname='+$("#cname").val(),
type: "POST",
success:function(data){
$("#course-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

function categoryfullAvail() {
	$("#loaderIcon").show();
jQuery.ajax({
url: "category_availability.php",
data:'cfull='+$("#cfull").val(),
type: "POST",
success:function(data){
$("#course-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

function categoryimageAvail() {
	$("#loaderIcon").show();
jQuery.ajax({
url: "category_availability.php",
data:'cimage='+$("#cimage").val(),
type: "POST",
success:function(data){
$("#course-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

</script>
</form>
</body>

</html>
<?php } ?>
