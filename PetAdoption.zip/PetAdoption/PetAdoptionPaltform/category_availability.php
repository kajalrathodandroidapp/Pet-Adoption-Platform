<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "petadoptiondb";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);
if(!empty($_POST['cname'])){
$cshort=$_POST['cname'];
$result ="SELECT count(*) FROM tbl_category WHERE cname=?";
$stmt = $mysqli->prepare($result);
$stmt->bind_param('s',$cname);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
if($count>0)
	echo "<span style='color:red'> Course Short Name Already Exist .</span>";
}
if(!empty($_POST['cname1'])){
$cshort=$_POST['cname1'];
$result ="SELECT count(*) FROM  pet WHERE cname=?";
$stmt = $mysqli->prepare($result);
$stmt->bind_param('i',$cname);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
if($count>0)
	echo "<span style='color:red'> Course Short Name Already Exist .</span>";
}

if(!empty($_POST['cfull'])){
	$cfull=$_POST['cfull'];
	$result ="SELECT count(*) FROM tbl_category WHERE cfull=?";
	$stmt = $mysqli->prepare($result);
	$stmt->bind_param('s',$cfull);
	$stmt->execute();
	$stmt->bind_result($count);
	$stmt->fetch();
	$stmt->close();
	if($count>0)
		echo "<span style='color:red'> Course Full Name Already Exist .</span>";
}

if(!empty($_POST['cfull1'])){
	$cfull=$_POST['cfull1'];
	$result ="SELECT count(*) FROM pet WHERE cfull=?";
	$stmt = $mysqli->prepare($result);
	$stmt->bind_param('s',$cfull);
	$stmt->execute();
	$stmt->bind_result($count);
	$stmt->fetch();
	$stmt->close();
	if($count>0)
		echo "<span style='color:red'> Course Full Name Already Exist .</span>";
}

if(!empty($_POST['cimage'])){
	$cfull=$_POST['cimage'];
	$result ="SELECT count(*) FROM tbl_category WHERE cimage=?";
	$stmt = $mysqli->prepare($result);
	$stmt->bind_param('s',$cimage);
	$stmt->execute();
	$stmt->bind_result($count);
	$stmt->fetch();
	$stmt->close();
	if($count>0)
		echo "<span style='color:red'> Category Image Already Exist .</span>";
}

if(!empty($_POST['cimage1'])){
	$cfull=$_POST['cimage1'];
	$result ="SELECT count(*) FROM pet WHERE cimage=?";
	$stmt = $mysqli->prepare($result);
	$stmt->bind_param('s',$cimage);
	$stmt->execute();
	$stmt->bind_result($count);
	$stmt->fetch();
	$stmt->close();
	if($count>0)
		echo "<span style='color:red'> Category Image Already Exist .</span>";
}
?>

